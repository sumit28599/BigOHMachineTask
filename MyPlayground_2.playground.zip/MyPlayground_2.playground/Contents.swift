import Foundation

// MARK: - PowerSource Protocol (Abstraction for all power sources)
protocol PowerSource {
    var powerRating: Double { get }
    func start()
    func stop()
}


// MARK: - EnergyGeneration Protocol (for generating energy)
protocol EnergyGeneration {
    func generatePower() -> Double
}

// MARK: - EnergySelling Protocol (for selling energy to the grid)
protocol EnergySelling {
    func sellExcessEnergy()
}

// MARK: - Battery Class (Manages energy storage)
class Battery {
    var capacity: Double  // in Watt-hour
    var chargeLevel: Double  // in percentage
    
    init(capacity: Double, chargeLevel: Double = 0.0) {
        self.capacity = capacity
        self.chargeLevel = chargeLevel
    }
    
    func charge() {
        chargeLevel = 100.0
        print("Battery is fully charged.")
    }
    
    func discharge() {
        chargeLevel = 0.0
        print("Battery is drained.")
    }
}

// MARK: - SolarPanel Class (Energy generation from solar panels)
class SolarPanel: EnergyGeneration {
    var efficiency: Double  // in percentage
    var area: Double  // in square meters
    
    init(efficiency: Double, area: Double) {
        self.efficiency = efficiency
        self.area = area
    }
    
    func generatePower() -> Double {
        return area * efficiency  // Simple power calculation
    }
}

// MARK: - Inverter Class (Base class for all inverters)
class Inverter: PowerSource {
    var powerRating: Double
    var battery: Battery?
    
    init(powerRating: Double, battery: Battery?) {
        self.powerRating = powerRating
        self.battery = battery
    }
    
    func start() {
        print("Inverter started with power rating \(powerRating)W.")
    }
    
    func stop() {
        print("Inverter stopped.")
    }
    
    func operate() {
        print("Operating inverter with power rating \(powerRating)W.")
    }
}

// MARK: - SolarInverter Class (Handles solar panel inverters)
class SolarInverter: Inverter, EnergyGeneration {
    var solarPanel: SolarPanel
    
    init(powerRating: Double, battery: Battery?, solarPanel: SolarPanel) {
        self.solarPanel = solarPanel
        super.init(powerRating: powerRating, battery: battery)
    }
    
    override func start() {
        super.start()
        let generatedPower = solarPanel.generatePower()
        print("Solar inverter started. Solar panel generated \(generatedPower)W.")
    }
    
    func generatePower() -> Double {
        return solarPanel.generatePower()
    }
}

// MARK: - Specialized Inverters (GTI, PCU, Regalia)
class GTI: SolarInverter, EnergySelling {
    // GTI inverter does not have battery, but it can sell energy to the grid
    init(powerRating: Double, solarPanel: SolarPanel) {
        super.init(powerRating: powerRating, battery: nil, solarPanel: solarPanel)
    }
    
    override func operate() {
        super.operate()
        sellExcessEnergy() // GTI inverter can sell energy to the grid
    }
    
    func sellExcessEnergy() {
        print("Selling excess energy back to the grid.")
    }
}

class PCU: SolarInverter {
    // PCU has battery and operates with both solar panel and battery
    init(powerRating: Double, battery: Battery, solarPanel: SolarPanel) {
        super.init(powerRating: powerRating, battery: battery, solarPanel: solarPanel)
    }
    
    override func operate() {
        super.operate()
        print("PCU inverter is also storing energy in the battery.")
    }
}

class Regalia: SolarInverter, EnergySelling {
    // Regalia has both battery and grid selling feature
    init(powerRating: Double, battery: Battery, solarPanel: SolarPanel) {
        super.init(powerRating: powerRating, battery: battery, solarPanel: solarPanel)
    }
    
    override func operate() {
        super.operate()
        sellExcessEnergy() // Can sell energy like GTI
        print("Regalia inverter is storing energy in battery.")
    }
    
    func sellExcessEnergy() {
        print("Selling excess energy back to the grid.")
    }
}

// MARK: - Non-Solar Inverters (Simple Home Inverters)
class SimpleInverter: Inverter {
    init(powerRating: Double, battery: Battery) {
        super.init(powerRating: powerRating, battery: battery)
    }
    
    override func operate() {
        print("Simple inverter is providing backup power with battery.")
    }
}

// MARK: - Demonstration of Usage
let battery = Battery(capacity: 2000.0, chargeLevel: 50.0)
let solarPanel = SolarPanel(efficiency: 0.2, area: 25.0)

let gtiInverter = GTI(powerRating: 3000.0, solarPanel: solarPanel)
let pcuInverter = PCU(powerRating: 5000.0, battery: battery, solarPanel: solarPanel)
let regaliaInverter = Regalia(powerRating: 6000.0, battery: battery, solarPanel: solarPanel)
let simpleInverter = SimpleInverter(powerRating: 1000.0, battery: battery)

gtiInverter.start()
gtiInverter.operate()

pcuInverter.start()
pcuInverter.operate()

regaliaInverter.start()
regaliaInverter.operate()

simpleInverter.start()
simpleInverter.operate()
