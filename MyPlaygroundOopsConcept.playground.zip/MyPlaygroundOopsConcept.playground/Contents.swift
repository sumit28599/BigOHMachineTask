import Foundation

protocol Arrestable {
    func canBeArrested() -> Bool
}

protocol SpendingLimit {
    var spendingLimit: Double { get set }
    var expenses: Double { get set }
    func exceedsSpendingLimit() -> Bool
}

protocol Mpprotocol {
    var constituencyName: Constituency { get set }
    var driver: Driver { get set }
}

class MPDetails: Mpprotocol, Arrestable, SpendingLimit {
    
    var spendingLimit: Double
    var expenses: Double
    var constituencyName: Constituency
    var driver: Driver
    
    init(constituencyName: Constituency, spendingLimit: Double, expenses: Double, driver: Driver) {
        self.constituencyName = constituencyName
        self.spendingLimit = spendingLimit
        self.expenses = expenses
        self.driver = driver
    }
    
    func exceedsSpendingLimit() -> Bool {
        return expenses > spendingLimit
    }
    
    func canBeArrested() -> Bool {
        return exceedsSpendingLimit()
    }
}

class Minister: Mpprotocol, Arrestable, SpendingLimit {
    
    var pmApprovalRequired: Bool
    var spendingLimit: Double
    var expenses: Double
    var constituencyName: Constituency
    var driver: Driver
    
    init(constituencyName: Constituency, spendingLimit: Double, expenses: Double, driver: Driver, pmApprovalRequired: Bool = true) {
        self.pmApprovalRequired = pmApprovalRequired
        self.constituencyName = constituencyName
        self.spendingLimit = spendingLimit
        self.expenses = expenses
        self.driver = driver
    }
    
    func exceedsSpendingLimit() -> Bool {
        return expenses > spendingLimit
    }

    func canBeArrested() -> Bool {
        // PM's approval required check
        if pmApprovalRequired {
            return false // Cannot be arrested without approval
        } else {
            return exceedsSpendingLimit()
        }
    }
}

class PM: Mpprotocol, Arrestable {
    
    var constituencyName: Constituency
    var driver: Driver
    var expenses: Double
    var specialVehicle: Aircraft
    
    init(constituencyName: Constituency, expenses: Double, driver: Driver, specialVehicle: Aircraft) {
        self.specialVehicle = specialVehicle
        self.constituencyName = constituencyName
        self.expenses = expenses
        self.driver = driver
    }

    func canBeArrested() -> Bool {
        return false // PM cannot be arrested
    }
    
    // PM gives approval for Minister arrest
    func givePermissionToArrestMinister(minister: Minister) {
        minister.pmApprovalRequired = false
    }
}

// Aircraft (PM’s Special Vehicle) - Composition
class Aircraft {
    var type: String
    
    init(type: String) {
        self.type = type
    }
}

// Driver Class (MP's driver is a Composition)
class Driver: Person {
    var name: String
    init(name: String, personName: String) {
        self.name = name
        super.init(personName: personName)
    }
}

class Person {
    var personName: String
    init(personName: String) {
        self.personName = personName
    }
}

class Constituency {
    var constituencyName: String
    
    init(constituencyName: String) {
        self.constituencyName = constituencyName
    }
}

// Commissioner Class (Arresting functionality)
class Commissioner {
    func canArrest(politicians: [Arrestable]) {
        for politician in politicians {
            if politician.canBeArrested() {
                print("\(politician) can be arrested for exceeding spending limit.")
            } else {
                print("\(politician) cannot be arrested.")
            }
        }
    }
}

// Create a Driver for MP, Minister, and PM
let driver1 = Driver(name: "Driver 1", personName: "MP 1")
let driver2 = Driver(name: "Driver 2", personName: "Minister 1")
let driver3 = Driver(name: "Driver 3", personName: "PM 1")

// Create a Constituency for MP, Minister, and PM
let constituency1 = Constituency(constituencyName: "Constituency A")
let constituency2 = Constituency(constituencyName: "Constituency B")
let constituency3 = Constituency(constituencyName: "National")

// Create Aircraft for PM
let aircraft1 = Aircraft(type: "Airbus A320")

let mp1 = MPDetails(constituencyName: constituency1, spendingLimit: 100000, expenses: 120000, driver: driver1)
let minister1 = Minister(constituencyName: constituency2, spendingLimit: 1000000, expenses: 1500000, driver: driver2)
let pm1 = PM(constituencyName: constituency3, expenses: 2000000, driver: driver3, specialVehicle: aircraft1)

// Create Commissioner
let commissioner = Commissioner()

// Check who can be arrested
commissioner.canArrest(politicians: [mp1, minister1, pm1])

// PM gives permission to arrest Minister if exceeded spending limit
pm1.givePermissionToArrestMinister(minister: minister1)

// Now check again
commissioner.canArrest(politicians: [mp1, minister1, pm1])


