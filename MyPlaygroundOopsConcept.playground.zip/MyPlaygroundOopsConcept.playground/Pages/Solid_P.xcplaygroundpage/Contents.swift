

//MARK: Single-responsibility principle


class SRP {
    var firstname:Firstname?
    var fullname:FullName?
    
    init(firstname: Firstname, fullname:FullName?) {
        self.firstname = firstname
        self.fullname = fullname
        
    }
    
    func printfullname() {
        guard let firstname else {return}
        guard let fullname  else {return}
        
        let name = firstname.prindata()
        fullname.prindatas(data: name)
    }
}


class Firstname {
    var firstname: String
    var lastname: String
    init(firstname: String,lastname: String) {
        self.firstname = firstname
        self.lastname = lastname
    }
    
    func prindata() -> String {
        return "\(firstname) \(lastname)"
    }
}

class FullName {
    func prindatas(data: Any) {
        print("Your Name is \(data)")
    }
}


let firstname = Firstname(firstname: "Donald", lastname: "Trump")
let fullname = FullName()

let srp = SRP(firstname: firstname, fullname: fullname)
srp.printfullname()



//MARK:  Open–closed principle

protocol Info {
    func animalInfo()
}

class Dog: Info {
    
    var name : String
    init(name: String) {
        self.name = name
    }
    func animalInfo() {
        print("Animal is Dog and this is  \(name)")
    }
}

class Cat: Info {
    
    var name: String
    init(name: String) {
        self.name = name
    }
    func animalInfo() {
        print("Animal is Cat and this is \(name)")
    }
}

class Lion: Info {
    
    var name: String
    init(name: String) {
        self.name = name
    }
    func animalInfo() {
        print("Animal is Cat and this is \(name)")
    }
}


class AnimalInfo {
    func animalinformation() {
        let animal: [Info] = [Dog(name: "Honey"),
                              Dog(name: "Rockey"),
                              Dog(name: "Jockey"),
                              Lion(name: "Tiger"),
                              Lion(name: "Dora"),
                              Lion(name: "Shera"),
                              Cat(name: "Cuty"),
                              Cat(name: "Princy"),
                              Cat(name: "Tom")]
        
        for info in animal {
            info.animalInfo()
        }
    }
}


let animalInfo = AnimalInfo()
animalInfo.animalinformation()



//MARK: Liskov substitution principle
//class Operator {
//    func addition(num1:Int,num2:Int) -> Int {
//        return num1 + num2
//    }
//}
//
//class Calculate: Operator {
//    override func addition(num1: Int, num2: Int) -> Int {
//        return num1 + num2
//    }
//    func addition(num1: Int, num2: Int,num3:Int) -> Int {
//        return num1 + num2 + num3
//    }
//}
//
//let operators = Operator()
//operators.addition(num1: 34, num2: 56)
//
//let calculate = Calculate()
//calculate.addition(num1: 34, num2: 56)
//calculate.addition(num1: 34, num2: 45, num3: 99)
//
////MARK: Interface segregation principle
//
//protocol Flyable {
//    func fly()
//}
//
//protocol Swimabble {
//    func swim()
//}
//
//protocol Feedable {
//    func eat()
//}
//
//class Flamingo: Flyable,Swimabble,Feedable {
//    func eat() {
//        print("I can eat")
//    }
//    
//    func fly() {
//        print("I can fly")
//    }
//    
//    func swim() {
//        print("I can swim")
//    }
//}
//
//class Dog: Feedable {
//    func eat() {
//        print("I can eat")
//    }
//    
//}


//MARK:  Dependency inversion principle

//protocol Animal {
//    func makeSound()
//}
//
//class Dog: Animal {
//    func makeSound() {
//        print("Bark")
//    }
//}
//
//class Cat: Animal {
//    func makeSound() {
//        print("Meau")
//    }
//}
//
//class AnimalFactory {
//    let animal: Animal
//    init(animal: Animal) {
//        self.animal = animal
//    }
//    
//    func printSound() {
//        animal.makeSound()
//    }
//}
//
//let dog = Dog()
//let animalvoice = AnimalFactory(animal: dog)
//animalvoice.printSound()
