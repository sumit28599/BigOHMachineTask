//Write code for below statement using solid principle with swift
//As described task is:
//You have to create a program for ATM Which would have certain defined denominations of notes : 100 ,200, 500, and 2000 INR.
//Now you have to design your ATM in such a way that at any time ATM can be top-up with any required domination like I can add 41000 as (2000 x 20) + (500 x 2) notes
//Your ATM should have a function to withdraw cash , input can be any amount:
//Use cases for withdraw as below:
//1: if amount is not present show error insufficient balance
//2: if amount is not in the factor of available denominations show error to ask for multiple of available denomination
//3: first largest denomination should be used than smaller : like if I opt for 2300 rs, amount dispatched should be (2000 x 1 ) + (200 x 1) + (100 x 1)
//3.b: if any denomination is not there like suppose you don’t have 2000 notes left in ATM , then, amount dispatched should be (500 x 4) + (200 x 1) + (100 x 1)
//
//Next step: it can be done by Modi Ji, that older denomination is not valid in case of demonetization, like 2000 Notes are banned and new 5000 notes are legal , so you code should be like you don’t need to change much of it,
//Try to achieve OOPS , and SOLID principles as much as you can,
//Also, we will add new use cases to see whether your system can adapt to those changes. If Not, then your design is bad. (SOLID,TRY,YAGNI,KISS)




import Foundation

protocol DetailsOfNotes {
    var amountOfNote: Int { get set }
    var numberOfNotes: Int { get set }
    
    func createFactorOfNotes(amount: Int) -> [Int]?
}

class CreateNoteForTransaction: DetailsOfNotes {
    var amountOfNote: Int
    var numberOfNotes: Int
    
    init(amountOfNote:Int,numberOfNotes: Int) {
        self.amountOfNote = amountOfNote
        self.numberOfNotes = numberOfNotes
        
    }
    
    func createFactorOfNotes(amount: Int) -> [Int]? {
        let neededNotes = amount / amountOfNote
        if neededNotes <= numberOfNotes {
            return Array(repeating: amountOfNote, count: neededNotes)
        }
        return nil
    }
}

class ATM {
    private var detailsofnotes: [DetailsOfNotes]
    
    init(detailsofnotes: [DetailsOfNotes]) {
        self.detailsofnotes = detailsofnotes
    }
    
    func addDetailsofnotes(newDetailsofnotes: [DetailsOfNotes]) {
        self.detailsofnotes.append(contentsOf: newDetailsofnotes)
    }
    
    func withdraw(amount: Int) -> String {
        guard isMultipleOfAvailableNotes(amount) else {
            return "Error: Amount must be a multiple of available denominations."
        }
        
        var remainingAmount = amount
        var result = [Int]()
        
        let sortedDetailsofnotes = detailsofnotes.sorted { $0.amountOfNote > $1.amountOfNote }
        
        for detailsofnotes in sortedDetailsofnotes {
            if remainingAmount >= detailsofnotes.amountOfNote {
                let notesRequired = remainingAmount / detailsofnotes.amountOfNote
                let availableNotes = min(notesRequired, detailsofnotes.numberOfNotes)
                remainingAmount -= availableNotes * detailsofnotes.amountOfNote
                result.append(contentsOf: Array(repeating: detailsofnotes.amountOfNote, count: availableNotes))
            }
        }
        
        if remainingAmount > 0 {
            return "Error: Insufficient balance to fulfill the amount."
        }
        
        return "Getting Notes: \(result.map { "\($0) INR" }.joined(separator: ", "))"
    }
    
    private func isMultipleOfAvailableNotes(_ amount: Int) -> Bool {
        let availableDenominations = detailsofnotes.map { $0.amountOfNote }
        return availableDenominations.contains(where: { amount % $0 == 0 })
    }
}

let noteof100 = CreateNoteForTransaction(amountOfNote: 100, numberOfNotes: 50)
let noteof200 = CreateNoteForTransaction(amountOfNote: 200, numberOfNotes: 50)
let noteof500 = CreateNoteForTransaction(amountOfNote: 500, numberOfNotes: 50)
let noteof2000 = CreateNoteForTransaction(amountOfNote: 5000, numberOfNotes: 50)


let atm = ATM(detailsofnotes: [noteof100,noteof200,noteof500,noteof2000])

let result = atm.withdraw(amount: 2300)
print(result)
let result2 = atm.withdraw(amount: 120)
print(result2)
let result3 = atm.withdraw(amount: 50000)
print(result3)
let result4 = atm.withdraw(amount: 5000)
print(result4)




