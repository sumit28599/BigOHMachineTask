
//Create a whats app as following
//Users have contacts and can chat with any contact
//Messaging in text audio and video
//Users can see the status of all the contacts
//Users can post status
//Status can be text and image

import Foundation

enum MessageType {
    case textMessage, audioMessage, videoMessage
}

enum StatusType {
    case textStatus, imageStatus
}

protocol Message {
    var sender: User {get}
    var receiver: Contact {get}
    var timestamp: Date {get}
    func displayMessage() -> String
}

protocol Status {
    var user: User {get}
    var statustext: String {get}
    func displayStatus() -> String
}



class TextMessage: Message {
    var content: String
    var sender: User
    var receiver: Contact
    var timestamp: Date
    
    init(content: String, sender: User, receiver: Contact, timestamp: Date) {
        self.content = content
        self.sender = sender
        self.receiver = receiver
        self.timestamp = timestamp
    }
    
    func displayMessage() -> String {
        return "\(sender.name) Sending text message to \(receiver.contact.name): \(content)"
    }
}

class AudioMessage: Message {
    var sender: User
    var receiver: Contact
    var timestamp: Date
    var audioFileText: String
    
    
    init(sender: User, receiver: Contact, timestamp: Date, audioFileText: String) {
        self.sender = sender
        self.receiver = receiver
        self.timestamp = timestamp
        self.audioFileText = audioFileText
    }
    
    func displayMessage() -> String {
        return "\(sender.name) Sending audio file to \(receiver.contact.name): \(audioFileText)"
    }
}

class VideoMessage: Message {
    var sender: User
    var receiver: Contact
    var timestamp: Date
    var videoFileText: String
    
    init(sender: User, receiver: Contact, timestamp: Date, videoFileText: String) {
        self.sender = sender
        self.receiver = receiver
        self.timestamp = timestamp
        self.videoFileText = videoFileText
    }
    
    func displayMessage() -> String {
        return "\(sender.name) Sending video file to \(receiver.contact.name): \(videoFileText)"
    }
}



class TextStatus: Status {
    var user: User
    
    var statustext: String
    
    init(user: User, statustext: String) {
        self.user = user
        self.statustext = statustext
    }
    
    func displayStatus() -> String {
        return "Status: \(statustext)"
    }
}

class ImageStatus: Status {
    var user: User
    var statustext: String
    
    init(user: User, statustext: String) {
        self.user = user
        self.statustext = statustext
    }
    
    func displayStatus() -> String {
        return "with image: \(statustext)"
    }
}

class MessageFactory {
    static func createMessage(type: MessageType, content: String,sender: User, receiver: Contact, timestamp: Date) -> Message? {
        switch type {
        case .textMessage:
            return TextMessage(content: content, sender: sender, receiver: receiver, timestamp: timestamp)
        case .audioMessage:
            return AudioMessage(sender: sender, receiver: receiver, timestamp: timestamp, audioFileText: content)
        case .videoMessage:
            return VideoMessage(sender: sender, receiver: receiver, timestamp: timestamp, videoFileText:content)
        }
    }
}

class StatusFactory {
    static func createStatus(type: StatusType, content: String, user:User) -> Status? {
        switch type {
        case .textStatus:
            return TextStatus(user: user, statustext: content)
        case .imageStatus:
            return ImageStatus(user: user, statustext: content)
        }
    }
}

class Contact {
    var contact: User
    
    init(contact: User) {
        self.contact = contact
    }
}

class User {
    var name: String
    var contactNumber: String
    var contacts: [Contact] = []
    
    init(name: String,contactNumber: String) {
        self.name = name
        self.contactNumber = contactNumber
    }
    
    func addContactByUser(contact: Contact) {
        contacts.append(contact)
    }
    
    func chatWithContactByUser(message: Message) {
        print("\(message.displayMessage())")
    }
    
    
    func viewContactsStatusesByUser() {
        for contact in contacts {
            print("\(contact.contact.name)'and contact number \(contact.contact.contactNumber)")
        }
    }
    
    func postStatusByUser(status: Status) {
        print("\(name) posted a status: \(status.displayStatus())")
    }
}


class WhatsApp {
    
    var whatsappContacts: [Contact] = []
    var whatsappUser : User
    var userNumber: String
    var whatsappAllMessage:[String: [String]] = [:]
    
    
    init(whatsappUser: User,userNumber: String) {
        self.whatsappUser = whatsappUser
        self.userNumber = userNumber
    }
    
    func addContactByWhatsapp(whatsappContact: Contact) {
        whatsappContacts.append(whatsappContact)
    }
    
     

         
    func viewContactsByWhatsappUser() {
        for contact in whatsappContacts {
            print("\(contact.contact.name)'and contact number \(contact.contact.contactNumber)")
        }
    }
    
    func showAllMessages() {
        for message in whatsappAllMessage {
            print("\(message.value) Our Conversations with contact \(message.key)")
        }
    }
    
    func sendMessage(type: MessageType, content: String, contact: Contact) {
        if userNumber == whatsappUser.contactNumber {
            if whatsappContacts.contains(where: {$0.contact.contactNumber == contact.contact.contactNumber}) {
                if let message = MessageFactory.createMessage(type: type, content: content, sender: whatsappUser, receiver: contact, timestamp: Date()) {
                    whatsappUser.chatWithContactByUser(message: message)
                    whatsappAllMessage[contact.contact.contactNumber, default: []].append(content)
                }
            } else {
                print("This is not use whatsapp")
            }
        } else {
            print("This is not whatsapp user")
        }
    }

    func postStatus(type: StatusType, content: String, contact: User) {
        if userNumber == whatsappUser.contactNumber {
            if whatsappContacts.contains(where: {$0.contact.contactNumber == contact.contactNumber}) {
                if let status = StatusFactory.createStatus(type: type, content: content, user: contact) {
                    contact.postStatusByUser(status: status)
                }
            } else {
                print("This is not whatsapp user")
            }
        } else {
            print("This is not whatsapp user")
        }
        
    }
}

class MainWhasappUser:@unchecked Sendable {
    
    static let shared  = MainWhasappUser()
    private init () {}
    var totalusers: Set<String> = []

    func addWhatsappUser(totaluser: WhatsApp) -> WhatsApp {
        totalusers.insert(totaluser.userNumber)
        return totaluser
        
    }
    
    func showAllUsers() {
        var count = 0
        for number in totalusers {
            count += 1
            print("All User\(count) \(number)")
        }
    }
}

let user1 = User(name: "Deepak Prajapati", contactNumber: "7897894567")
let user2 = User(name: "Shivam Singh", contactNumber: "9967454658")
let user3 = User(name: "Varun Pratap", contactNumber: "3456798765")
let user4 = User(name: "Vijay Pratap", contactNumber: "6786798765")

let contact1 = Contact(contact: user2)
let contact2 = Contact(contact: user3)
let contact3 = Contact(contact: user4)
user1.addContactByUser(contact: contact1)
user1.addContactByUser(contact: contact2)

let whatsapp = WhatsApp(whatsappUser: user1, userNumber: "7897894567")
let whatsapp1 = WhatsApp(whatsappUser: user4, userNumber: "6786798765")
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp1)

MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).addContactByWhatsapp(whatsappContact: contact1)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).addContactByWhatsapp(whatsappContact: contact2)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).sendMessage(type: .textMessage, content: "How are you ? \(user2.name)", contact: contact2)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).sendMessage(type: .audioMessage, content: "Audio Message", contact: contact2)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).sendMessage(type: .videoMessage, content: "Video Message", contact: contact2)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).showAllMessages()

MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp1).addContactByWhatsapp(whatsappContact: contact1)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp1).addContactByWhatsapp(whatsappContact: contact2)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp1).sendMessage(type: .textMessage, content: "How are you ? \(user2.name)", contact: contact1)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp1).sendMessage(type: .audioMessage, content: "Audio Message", contact: contact1)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp1).sendMessage(type: .videoMessage, content: "Video Message", contact: contact1)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).showAllMessages()
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).postStatus(type: .textStatus, content: "Feeling good today!", contact: user2)
MainWhasappUser.shared.addWhatsappUser(totaluser: whatsapp).postStatus(type: .imageStatus, content: "images", contact: user2)

MainWhasappUser.shared.showAllUsers()























































//import Foundation
//
//enum MessageType {
//    case textMessage, audioMessage, videoMessage
//}
//
//enum StatusType {
//    case textStatus, imageStatus
//}
//
//protocol Message {
//    var sender: User {get}
//    var receiver: Contact {get}
//    var timestamp: Date {get}
//    func displayMessage() -> String
//}
//
//protocol Status {
//    var user: User {get}
//    var statustext: String {get}
//    func displayStatus() -> String
//}
//
//
//
//class TextMessage: Message {
//    var content: String
//    var sender: User
//    var receiver: Contact
//    var timestamp: Date
//    
//    init(content: String, sender: User, receiver: Contact, timestamp: Date) {
//        self.content = content
//        self.sender = sender
//        self.receiver = receiver
//        self.timestamp = timestamp
//    }
//    
//    func displayMessage() -> String {
//        return "\(sender.name) Sending text message to \(receiver.contact.name): \(content)"
//    }
//}
//
//class AudioMessage: Message {
//    var sender: User
//    var receiver: Contact
//    var timestamp: Date
//    var audioFileText: String
//    
//    
//    init(sender: User, receiver: Contact, timestamp: Date, audioFileText: String) {
//        self.sender = sender
//        self.receiver = receiver
//        self.timestamp = timestamp
//        self.audioFileText = audioFileText
//    }
//    
//    func displayMessage() -> String {
//        return "\(sender.name) Sending audio file to \(receiver.contact.name): \(audioFileText)"
//    }
//}
//
//class VideoMessage: Message {
//    var sender: User
//    var receiver: Contact
//    var timestamp: Date
//    var videoFileText: String
//    
//    init(sender: User, receiver: Contact, timestamp: Date, videoFileText: String) {
//        self.sender = sender
//        self.receiver = receiver
//        self.timestamp = timestamp
//        self.videoFileText = videoFileText
//    }
//    
//    func displayMessage() -> String {
//        return "\(sender.name) Sending video file to \(receiver.contact.name): \(videoFileText)"
//    }
//}
//
//
//
//class TextStatus: Status {
//    var user: User
//    
//    var statustext: String
//    
//    init(user: User, statustext: String) {
//        self.user = user
//        self.statustext = statustext
//    }
//    
//    func displayStatus() -> String {
//        return "Status: \(statustext)"
//    }
//}
//
//class ImageStatus: Status {
//    var user: User
//    var statustext: String
//    
//    init(user: User, statustext: String) {
//        self.user = user
//        self.statustext = statustext
//    }
//    
//    func displayStatus() -> String {
//        return "with image: \(statustext)"
//    }
//}
//
//class MessageFactory {
//    static func createMessage(type: MessageType, content: String,sender: User, receiver: Contact, timestamp: Date) -> Message? {
//        switch type {
//        case .textMessage:
//            return TextMessage(content: content, sender: sender, receiver: receiver, timestamp: timestamp)
//        case .audioMessage:
//            return AudioMessage(sender: sender, receiver: receiver, timestamp: timestamp, audioFileText: content)
//        case .videoMessage:
//            return VideoMessage(sender: sender, receiver: receiver, timestamp: timestamp, videoFileText:content)
//        }
//    }
//}
//
//class StatusFactory {
//    static func createStatus(type: StatusType, content: String, user:User) -> Status? {
//        switch type {
//        case .textStatus:
//            return TextStatus(user: user, statustext: content)
//        case .imageStatus:
//            return ImageStatus(user: user, statustext: content)
//        }
//    }
//}
//
//class Contact {
//    var contact: User
//    
//    init(contact: User) {
//        self.contact = contact
//    }
//    
//    func sendMessageByContact(message: Message) {
//        print("\(message.displayMessage())")
//    }
//    
//    func postStatusByContact(status: Status) {
//        print("\(contact.name): \(status.displayStatus())")
//    }
//}
//
//class User {
//    var name: String
//    var contactNumber: String
//    var contacts: [Contact] = []
//    
//    init(name: String,contactNumber: String) {
//        self.name = name
//        self.contactNumber = contactNumber
//    }
//    
//    func addContactByUser(contact: Contact) {
//        contacts.append(contact)
//    }
//    
//    func chatWithContactByUser(contact: Contact, message: Message) {
//        contact.sendMessageByContact(message: message)
//    }
//    
//    
//    func viewContactsStatusesByUser() {
//        for contact in contacts {
//            print("\(contact.contact.name)'and contact number \(contact.contact.contactNumber)")
//        }
//    }
//    
//    func postStatusByUser(status: Status) {
//        print("\(name) posted a status: \(status.displayStatus())")
//    }
//}
//
//
//class WhatsApp {
//    
//    var whatsappContacts: [Contact] = []
//    var whatsappUser : User
//    var userNumber: String
//    var whatsappAllMessage:[String: [String]] = [:]
//    
//    init(whatsappUser: User,userNumber: String) {
//        self.whatsappUser = whatsappUser
//        self.userNumber = userNumber
//    }
//    
//    func addContactByWhatsapp(whatsappContact: Contact) {
//        whatsappContacts.append(whatsappContact)
//    }
//    
//     
//
//         
//    func viewContactsByWhatsappUser() {
//        for contact in whatsappContacts {
//            print("\(contact.contact.name)'and contact number \(contact.contact.contactNumber)")
//        }
//    }
//    
//    func showAllMessages() {
//        for message in whatsappAllMessage {
//            print("\(message.key) Our Conversations \(message.value)")
//        }
//    }
//    
//    func sendMessage(type: MessageType, content: String, contact: Contact) {
//        if userNumber == whatsappUser.contactNumber {
//            if whatsappContacts.contains(where: {$0.contact.contactNumber == contact.contact.contactNumber}) {
//                if let message = MessageFactory.createMessage(type: type, content: content, sender: whatsappUser, receiver: contact, timestamp: Date()) {
//                    whatsappUser.chatWithContactByUser(contact: contact, message: message)
//                    whatsappAllMessage[contact.contact.contactNumber, default: []].append(content)
//                    print("total meesage \(whatsappAllMessage)")
//                }
//            } else {
//                print("This is not use whatsapp")
//            }
//        } else {
//            print("This is not whatsapp user")
//        }
//    }
//
//    func postStatus(type: StatusType, content: String, contact: User) {
//        if userNumber == whatsappUser.contactNumber {
//            if whatsappContacts.contains(where: {$0.contact.contactNumber == contact.contactNumber}) {
//                if let status = StatusFactory.createStatus(type: type, content: content, user: contact) {
//                    contact.postStatusByUser(status: status)
//                }
//            } else {
//                print("This is not whatsapp user")
//            }
//        } else {
//            print("This is not whatsapp user")
//        }
//        
//    }
//}
//
//
//
//let user1 = User(name: "Deepak Prajapati", contactNumber: "7897894567")
//let user2 = User(name: "Shivam Singh", contactNumber: "9967454658")
//let user3 = User(name: "Varun Pratap", contactNumber: "3456798765")
//let user4 = User(name: "Vijay Pratap", contactNumber: "6786798765")
//
//let contact1 = Contact(contact: user2)
//let contact2 = Contact(contact: user3)
//let contact3 = Contact(contact: user4)
//user1.addContactByUser(contact: contact1)
//user1.addContactByUser(contact: contact2)
//
//let whatsapp = WhatsApp(whatsappUser: user1, userNumber: "7897894567")
//
//
//whatsapp.addContactByWhatsapp(whatsappContact: contact1)
//whatsapp.addContactByWhatsapp(whatsappContact: contact2)
//whatsapp.sendMessage(type: .textMessage, content: "How are you ? \(user2.name)", contact: contact2)
//whatsapp.sendMessage(type: .audioMessage, content: "Audio Message", contact: contact2)
//whatsapp.sendMessage(type: .videoMessage, content: "Video Message", contact: contact2)
//whatsapp.showAllMessages()
//
//
//whatsapp.postStatus(type: .textStatus, content: "Feeling good today!", contact: user2)
//whatsapp.postStatus(type: .imageStatus, content: "images", contact: user2)
