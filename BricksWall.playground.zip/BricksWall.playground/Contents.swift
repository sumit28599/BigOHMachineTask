
//Intent: user can paint brick in his/her city wall with caption, message and dedicate to someone on Valentine's day.
//> Anyone can read content of brick.
//> Anyone can comment on it.
//> Use cases:
//> Brick: Every country has n number of cities and every city can have 1 to n number of walls.
//> 1 wall can have max of 90 bricks. 2nd wall would be only initiated once all bricks of 1st wall will be occupied.
//> A brick can be only owned by a single guy..
//> When owner visits on his/her city wall then his brick should animate.
//> Need to find out total number of walls initiated, total number of bricks initiated in specific wall.
//> Admin can edit any brick whereas user can edit only his/her brick.
//> If more than 10 bricks would be flagged then brick would be in invisible mode.
//An owner can dedicate more than one brick to express his/ her love to more than one person whereas a specific brick can be only owned by one person.
//Find out hottest guy or girl that received max number of bricks.
//Find out the guy or girl that don't get any dedication.
//You can input 10 users from command line. Whole project should be able to run through command line.




import Foundation

enum VisibilityOfBricks {
    case visible, invisible
}

enum ActionOnBricks {
    case flagged, edited, dedicated
}

class Brick {
    var message: String
    var owner: User?
    var visibility: VisibilityOfBricks
    var actions: [ActionOnBricks] = []
    
    init(message: String) {
        self.message = message
        self.visibility = .visible
    }
    
    func flag() {
        actions.append(.flagged)
        if actions.filter({ $0 == .flagged }).count > 10 {
            visibility = .invisible
        }
    }
    
    func editMessage(newMessage: String) {
        message = newMessage
        actions.append(.edited)
    }
    
    func dedicateToUser(owner: User) {
        self.owner = owner
        actions.append(.dedicated)
    }
}

class Wall {
    var bricks: [Brick] = []
    
    func addBrick(brick: Brick) {
        if bricks.count < 90 {
            bricks.append(brick)
        } else {
            print("Wall is full, cannot add more bricks.")
        }
    }
}

class City {
    let name: String
    var walls: [Wall] = []
    
    init(name: String) {
        self.name = name
    }
    
    func addWall(wall: Wall) {
        walls.append(wall)
    }
    
    func totalWalls() -> Int {
        return walls.count
    }
    
    func totalBricksInWall(wallIndex: Int) -> Int? {
        if wallIndex < walls.count {
            return walls[wallIndex].bricks.count
        }
        return nil
    }
}

class User {
    let username: String
    var dedicatedBricks: [Brick] = []
    
    init(username: String) {
        self.username = username
    }
    
    func dedicateBrick(brick: Brick) {
        brick.dedicateToUser(owner: self)
        dedicatedBricks.append(brick)
    }
}


class BrickManager {
    static func findHottestUser(users: [User]) -> User? {
        return users.max { $0.dedicatedBricks.count < $1.dedicatedBricks.count }
    }
    
    static func findLeastDedicatedUser(users: [User]) -> User? {
        return users.min { $0.dedicatedBricks.count < $1.dedicatedBricks.count }
    }
    
    static func countTotalWallaInCity(city: City) -> Int {
        return city.totalWalls()
    }
    
    static func countTotalUseBricksInWall(city: City, wallIndex: Int) -> Int? {
        return city.totalBricksInWall(wallIndex: wallIndex)
    }
}

class Admin {
    static func editBrickMessage(brick: Brick, newMessage: String) {
        brick.editMessage(newMessage: newMessage)
    }
    
    static func flagBrick(brick: Brick) {
        brick.flag()
    }
}

class UserManager {
    static func editBrickMessageForUser(brick: Brick, newMessage: String, user: User) {
        guard brick.owner === user else {
            print("User can only edit their own brick.")
            return
        }
        brick.editMessage(newMessage: newMessage)
    }
    
    static func dedicateBrickToUser(brick: Brick, user: User) {
        user.dedicateBrick(brick: brick)
    }
}


class RunWithTestCases {
    var cities: [City] = []
    var users: [User] = []
    
    func start() {
        for i in 1...10 {
            let user = User(username: "User\(i)")
            users.append(user)
        }
        
        let city = City(name: "ValentineCity")
        cities.append(city)
        
        let wall1 = Wall()
        let wall2 = Wall()
        
        city.addWall(wall: wall1)
        city.addWall(wall: wall2)
        
        let brick1 = Brick(message: "I love you, User1!")
        wall1.addBrick(brick: brick1)
        
        UserManager.dedicateBrickToUser(brick: brick1, user: users[0])
        let brick2 = Brick(message: "You're amazing, User2!")
        for i in 1...90 {
            wall1.addBrick(brick: brick2)
        }
        
        print("number of bricks wall1 :\(wall1.bricks.count).")
        print("number of bricks wall2 :\(wall2.bricks.count).")
        UserManager.dedicateBrickToUser(brick: brick2, user: users[1])
        if let hottest = BrickManager.findHottestUser(users: users) {
            print("\(hottest.username) is the hottest user with \(hottest.dedicatedBricks.count) bricks.")
        }
        
        if let leastDedicated = BrickManager.findLeastDedicatedUser(users: users) {
            print("\(leastDedicated.username) is the least dedicated user with \(leastDedicated.dedicatedBricks.count) bricks.")
        }
        
        let totalWalls = BrickManager.countTotalWallaInCity(city: city)
        print("Total walls in \(city.name): \(totalWalls)")
        
        if let totalBricks = BrickManager.countTotalUseBricksInWall(city: city, wallIndex: 0) {
            print("Total bricks in wall 1: \(totalBricks)")
        }
    }
}

let runWithTestCases = RunWithTestCases()
runWithTestCases.start()

