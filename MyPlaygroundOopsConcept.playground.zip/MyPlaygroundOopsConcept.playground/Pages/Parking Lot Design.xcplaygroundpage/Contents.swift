//A parking lot or car park is a dedicated cleared area that is intended for parking vehicles.
//Use case
//Here are the main Actors in our system:
//Admin: Mainly responsible for adding and modifying parking floors, parking spots, entrance, and exit panels, adding/removing parking attendants, etc.
//Customer: All customers can get a parking ticket and pay for it.
//Parking attendant: Parking attendants can do all the activities on the customer’s behalf, and can take cash for ticket payment.
//System: To display messages on different info panels, as well as assigning and removing a vehicle from a parking spot.
//Here are the top use cases for Parking Lot:
//Add/Remove/Edit parking floor: To add, remove or modify a parking floor from the system. Each floor can have its own display board to show free parking spots.
//Add/Remove/Edit parking spot: To add, remove or modify a parking spot on a parking floor.
//Add/Remove a parking attendant: To add or remove a parking attendant from the system.
//Take ticket: To provide customers with a new parking ticket when entering the parking lot.
//Scan ticket: To scan a ticket to find out the total charge.
//Credit card payment: To pay the ticket fee with credit card.
//Cash payment: To pay the parking ticket through cash.
//Add/Modify parking rate: To allow admin to add or modify the hourly parking rate
//
//System Requirements
//We will focus on the following set of requirements while designing the parking lot:
//The parking lot should have multiple floors where customers can park their cars.
//The parking lot should have multiple entry and exit points.
//Customers can collect a parking ticket from the entry points and can pay the parking fee at the exit points on their way out.
//Customers can pay the tickets at the automated exit panel or to the parking attendant.
//Customers can pay via both cash and credit cards.
//Customers should also be able to pay the parking fee at the customer’s info portal on each floor. If the customer has paid at the info portal, they don’t have to pay at the exit.
//The system should not allow more vehicles than the maximum capacity of the parking lot. If the parking is full, the system should be able to show a message at the entrance panel and on the parking display board on the ground floor.
//Each parking floor will have many parking spots. The system should support multiple types of parking spots such as Compact, Large, Handicapped, Motorcycle, etc.
//The Parking lot should have some parking spots specified for electric cars. These spots should have an electric panel through which customers can pay and charge their vehicles.
//The system should support parking for different types of vehicles like car, truck, van, motorcycle, etc.
//Each parking floor should have a display board showing any free parking spot for each spot type.
//The system should support a per-hour parking fee model. For example, customers have to pay $4 for the first hour, $3.5 for the second and third hours, and $2.5 for all the remaining hours.




import Foundation


enum VehicleType {
    case car, truck, motorcycle, electricCar
}

enum SpotType {
    case compact, large, handicapped, motorcycle, electric
}

enum SpecificRole {
    case admin, parkingattendent
}

protocol PaymentMethod {
    func pay(amount: Double) -> Bool
}

class Vehicle {
    var vehicletype: VehicleType
    var license: String
    init(vehicletype: VehicleType, license: String) {
        self.vehicletype = vehicletype
        self.license = license
    }
}

class User {
    let username: String
    let specificRole: SpecificRole
    
    init(username: String, specificRole: SpecificRole) {
        self.username = username
        self.specificRole = specificRole
    }
}

class ParkingSpot {
    let spotNumber: Int
    var isOccupied: Bool = false
    var vehicle: Vehicle?
    let specificRole: SpecificRole
    let currentUser : User
    
    init(spotNumber: Int, vehicle: Vehicle,specificRole: SpecificRole,currentUser : User) {
        self.spotNumber = spotNumber
        self.isOccupied = false
        self.currentUser = currentUser
        self.specificRole = specificRole
    }
    
    func occupySpace(vehicle: Vehicle,currentUser : User) -> Bool {
        guard currentUser.specificRole == .admin else {
            print("Access Denied: Only Admin can occupy space.")
            return false
        }
        
        if !isOccupied {
            self.vehicle = vehicle
            self.isOccupied = true
            return true
        }
        return false
    }
    
    func freeSpace(vehicle: Vehicle,currentUser : User) -> Bool{
        guard currentUser.specificRole == .admin else {
            print("Access Denied: Only Admin can free space")
            return false
        }
        
        if isOccupied {
            self.isOccupied = false
            return true
        }
        return false
    }
}

class ParkingFloor {
    let floorNumber: Int
    var parkingSpots: [ParkingSpot]
    
    
    init(floorNumber: Int,parkingSpots: [ParkingSpot]) {
        self.floorNumber = floorNumber
        self.parkingSpots = parkingSpots
    }
    
    func addSpot(spot: ParkingSpot,specificRole: SpecificRole) {
        guard specificRole == .admin else {
            print("Access Denied: Only Admin can add spot")
            return
        }
        self.parkingSpots.append(spot)
    }
    
    
    func removeSpot(spot: ParkingSpot,specificRole: SpecificRole) {
        guard specificRole == .admin else {
            print("Access Denied: Only Admin can remove spot.")
            return
        }
        if let index = self.parkingSpots.firstIndex(where: { $0.spotNumber == spot.spotNumber }) {
            self.parkingSpots.remove(at: index)
        }
    }
}

class ParkingRate {
    var firstRate: Double
    var secondRate: Double
    var thirdRate: Double
    
    init(firstRate: Double, secondRate: Double, thirdRate: Double) {
        self.firstRate = firstRate
        self.secondRate = secondRate
        self.thirdRate = thirdRate
    }
}

class ParkingTicket {
    let vehicle: Vehicle
    let issueTime: Date
    let user:User
    var parkingRate:ParkingRate
    
    init(vehicle: Vehicle, issueTime: Date,user:User,parkingRate:ParkingRate) {
        self.issueTime = issueTime
        self.vehicle = vehicle
        self.user = user
        self.parkingRate = parkingRate
    }
    
    
    func totalParkingFee(forHours hours: Int) -> Double {
        var fee = 0.0
        guard hours > 0 else { return fee }
        
        if hours > 0 {
            fee += Double(min(hours, 1)) * parkingRate.firstRate//rate.firstRate
        }
        if hours > 1 {
            fee += Double(min(hours - 1, 2)) * parkingRate.secondRate
        }
        if hours > 3 {
            fee += Double(hours - 3) * parkingRate.thirdRate
        }
        return fee
    }
    
    
    
    func requestPayment(ticket: ParkingTicket, paymentMethod: CashPayment) -> Bool {
        guard user.specificRole == .parkingattendent else {
            print("Access Denied: Only Attendent can request for payment")
            return false
        }
        let hoursParked = Int(Date().timeIntervalSince(ticket.issueTime) / 3600)
        let totalFee = ticket.totalParkingFee(forHours: hoursParked)
        return paymentMethod.pay(amount: totalFee)
    }
    
    
    func issueTicket(forSpot spot: ParkingSpot,specificRole:SpecificRole,user :User) -> ParkingTicket {
        let ticket = ParkingTicket(vehicle: vehicle, issueTime: Date(), user: user, parkingRate: parkingRate)
        guard specificRole == .parkingattendent else {
            print("Access Denied: Only Admin can remove a parking floor.")
            return ticket
        }
        
        spot.occupySpace(vehicle: vehicle, currentUser: user)
        print("\(user.username) issued ticket for spot \(spot.spotNumber)")
        return ticket
    }
    
}


class CreditCardPayment: PaymentMethod {
    func pay(amount: Double) -> Bool {
        print("Paid $\(amount) via Credit Card")
        return true
    }
}

class CashPayment: PaymentMethod {
    func pay(amount: Double) -> Bool {
        print("Paid $\(amount) in Cash")
        return true
    }
}

class ParkingAttendant {
    let name: String
    let vehicle: Vehicle
    init(name: String,vehicle: Vehicle,user:User) {
        self.name = name
        self.vehicle = vehicle
    }
}

class InfoPanel {
    func displayMessage(message: String) {
        print("Info Panel: \(message)")
    }
}

class ParkingLotSystem {
    var ticket: [ParkingTicket]
    var attendants: [ParkingAttendant]
    var floors: [ParkingFloor]
    
    init() {
        self.ticket = []
        self.attendants = []
        self.floors = []
    }
    
    func collectTicket(fromAttendant attendant: ParkingTicket, spot: ParkingSpot,user:User) -> [ParkingTicket]{
        ticket.append(attendant.issueTicket(forSpot: spot, specificRole: .parkingattendent, user: user))
        return ticket
         
    }
    func addParkingFloor(floor: ParkingFloor, user: User) {
        guard user.specificRole == .admin else {
            print("Access Denied: Only Admin can remove a parking floor.")
            return
        }
        floors.append(floor)
        print("Added  Attendant \(floor.floorNumber)")
        
        
    }
    
    func removeParkingFloor(floor: ParkingFloor, user: User) {
        guard user.specificRole == .admin else {
            print("Access Denied: Only Admin can remove a parking floor.")
            return
        }
        if let index = floors.firstIndex(where: { $0.floorNumber == floor.floorNumber }) {
            floors.remove(at: index)
            print("Removed Parking Floor \(floor.floorNumber)")
        }
        
    }
    
    
    func addAttendant(attendant: ParkingAttendant,user: User) {
        guard user.specificRole == .admin else {
            print("Access Denied: Only Admin can Add attendent.")
            return
        }
        attendants.append(attendant)
        print("Added  Attendant \(attendant.name)")
    }
    
    func removeAttendant(attendant: ParkingAttendant,user: User) {
        guard user.specificRole == .admin else {
            print("Access Denied: Only Admin can remove a attendent.")
            return
        }
        if let index = attendants.firstIndex(where: { $0.name == attendant.name }) {
            attendants.remove(at: index)
            print("Removed  Attendant \(attendant.name)")
        }
    }
}



let parkingrate = ParkingRate(firstRate: 1.2, secondRate: 4.5, thirdRate: 6.5)
let vehicle = Vehicle(vehicletype: .car, license: "11234567")
let currentUser = User(username: "Sumit", specificRole: .parkingattendent)
let parkingSpot = ParkingSpot(spotNumber: 1, vehicle: vehicle, specificRole: .admin, currentUser: currentUser)
let ticket = ParkingTicket(vehicle: vehicle, issueTime: Date(), user: currentUser, parkingRate: parkingrate)
let paymentmethod = CashPayment()
ticket.issueTicket(forSpot: parkingSpot, specificRole: .parkingattendent, user:currentUser)




