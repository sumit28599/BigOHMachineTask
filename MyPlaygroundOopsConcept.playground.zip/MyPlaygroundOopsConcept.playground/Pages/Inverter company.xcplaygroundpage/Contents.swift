

//Task 2:
//suppose you are making a program for a very famous IoT Inverter company,
//company have multiple inverters with multiple business logic,
//use cases:
//company have PCU, GTI, Zelio, Regalia, iCruze Inverters,
//All Inverters have Power rating which is determined by ( Current * Operating Voltage )
//Only PCU, GTI and Regalia are solar Inverters other are not (solar inverters get charge by solar panels and solar energy),
//Solar Inverters have Solar Panels also
//Solar Inverters further have two option one Battery version that whatever energy is produced will be stored in battery other will not store any energy,
//so PCU comes with battery but GTI have no battery,
//Solar Inverter also have GRID On , system where you can sell your extra energy back, GTI is GRID On where as this feature is not available in PCU,
//Non Solar Inverters are Simple Home Inverters Which have a Battery,"


import Foundation

protocol PowerRating {
    func calculatePowerRating()
    func storePower()
}
protocol PowerGenerator {
    func generatePower() -> Double
}



class BatteryCapacity {
    var batteryVersion :Double
    var batteryChargeValue :Double
    init(batteryVersion: Double,batteryChargeValue: Double) {
        self.batteryVersion = batteryVersion
        self.batteryChargeValue = batteryChargeValue
    }
    
    func fullChargeBattery() {
        batteryChargeValue = 100.0
        print("Battery Charge Value \(batteryChargeValue) and It's version \(batteryVersion)")
    }
    
    func dischargeBattery() {
        batteryChargeValue = 0.0
        print("Battery Charge Value \(batteryChargeValue) and It's version \(batteryVersion)")
    }
    
}

class Inverter: PowerRating {
    var current: Double
    var operatingVoltage: Double
    var battery: BatteryCapacity?
    
    init(current: Double, operatingVoltage: Double, battery:BatteryCapacity?) {
        self.current = current
        self.operatingVoltage = operatingVoltage
        self.battery = battery
    }
    
    func calculatePowerRating()  {
        print("Inverter started with power rating \(current * operatingVoltage).")
    }
    
    func storePower()  {
        print("Inverter started with power rating \(current * operatingVoltage).")
    }
}

class SolarPanel: PowerGenerator {
    var efficiency: Double
    var area: Double
    
    init(efficiency: Double, area: Double) {
        self.efficiency = efficiency
        self.area = area
    }
    
    func generatePower() -> Double {
        return area * efficiency 
    }
}

class SolarInverter: Inverter, PowerGenerator {
    
    var solarPanel: SolarPanel
    var gridOn: Bool?
    init(gridOn: Bool?,solarPanel: SolarPanel, current: Double, operatingVoltage: Double, battery: BatteryCapacity?) {
        self.solarPanel = solarPanel
        self.gridOn = gridOn
        super.init(current: current, operatingVoltage: operatingVoltage, battery: battery)
    }
    
    override func calculatePowerRating() {
        super.calculatePowerRating()
        let generatedPower = solarPanel.generatePower()
        print("Solar inverter started. Solar panel generated \(generatedPower)W.")
    }
    
    
    func generatePower() -> Double {
        return solarPanel.generatePower()
    }
}

class PCU: SolarInverter {
    init(gridOn: Bool?,current: Double, operatingVoltage: Double, battery: BatteryCapacity, solarPanel: SolarPanel) {
        super.init(gridOn: gridOn, solarPanel: solarPanel, current: current, operatingVoltage: operatingVoltage, battery: battery)
    }
     
    override func storePower() {
        super.storePower()
        print("PCU inverter is also storing energy in the battery.")
    }
}

class GTI: SolarInverter {
    
    init(gridOn: Bool?,current: Double, operatingVoltage: Double, solarPanel: SolarPanel) {
        super.init(gridOn: gridOn,solarPanel: solarPanel, current: current, operatingVoltage: operatingVoltage, battery: nil)
    }
     
    override func storePower() {
        super.storePower()
        releasePower()
    }
    
    func releasePower() {
        print("GTI have no battery then release power to another source.")
    }
}

class SimpleInverter: Inverter {
    override init(current: Double, operatingVoltage: Double, battery: BatteryCapacity?) {
        super.init(current: current, operatingVoltage: operatingVoltage, battery: battery)
    }
    override func storePower() {
        print("Simple inverter is providing backup power with battery.")
    }
}

let battery = BatteryCapacity(batteryVersion: 2.5, batteryChargeValue: 50.0)
let invertor = Inverter(current: 24.0, operatingVoltage: 56.0, battery: battery)
let solarpanel = SolarPanel(efficiency: 0.8, area: 45)
let solarInverter = SolarInverter(gridOn: true, solarPanel: solarpanel, current: 34.0, operatingVoltage: 47.0, battery: battery)
let pcu = PCU(gridOn: false, current: 56.0, operatingVoltage: 56.0, battery: battery, solarPanel: solarpanel)
let gti = GTI(gridOn: true, current: 56.0, operatingVoltage: 56.0, solarPanel: solarpanel)
let simpleinvertor = SimpleInverter(current: 35.0, operatingVoltage: 56.0, battery: battery)

solarInverter.generatePower()
solarInverter.calculatePowerRating()
pcu.storePower()
pcu.calculatePowerRating()
pcu.generatePower()
gti.releasePower()
gti.storePower()
simpleinvertor.storePower()
