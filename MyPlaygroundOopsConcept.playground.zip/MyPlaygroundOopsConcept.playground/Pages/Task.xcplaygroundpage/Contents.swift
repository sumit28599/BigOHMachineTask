//Hotel Management system
//Problem Statement :
//Application for Hotel reservation. We will take the selection criteria from user and display the hotels list for user basing on the criteria. User can book the room if there is availability of the rooms in that particular hotel. There are three different types of user roles for the application they are administrator , hotel agent and normal user. Following are the actions provided for each user.
//Normal user :
//Can register for the site
//Search the hotel details basing on the criteria.
//Book the hotel room
//Can modify the self details.
//Hotel Agent:
//Can register for the site
//Can add/update the details of the hotel.
//Adminstrator:
//Will approve the new hotel details added to the application
//Can delete the user/hotel details.
//Minimal Features :
//Adding Hotel information such as hotel name, location, number of rooms , facilities etc. to the database
//Listing the hotels based on different criteria selected by the user.
//User able to select a hotel and book a room.
//Booking permitted only if there are rooms available
//Displaying the reservation status.
//Registration of users.
//Update user details.
//Modify hotel details.
//Approval of the details entered by the hotel agent.
//Delete user/hotel details by admin
//Additional Features:
//Taking Feedback from user.
//Rating the hotels based on the feedback.
//Goals:
//To complete the hotel booking flow, registration of the users, adding details of the hotels.
//Deliverables:
//Minimal Features and additional features provided if time permits.
//Out of scope:
//We are not embedding payment gateway in the current application we will try if time permits after completion of additional features.


import Foundation


protocol User {
    var username: String { get }
    var email: String { get set }
    func register()
}

protocol HotelAgentProtocol: User {
    func addHotel(hotel: Hotel)
    func updateHotelDetails(hotel: Hotel)
}

protocol AdministratorProtocol: User {
    func approveHotel(hotel: Hotel)
    func deleteUser(user: User)
    func deleteHotel(hotel: Hotel)
}

protocol BookForRoom {
    var numberOfRooms: [Room] { get }
    func bookRoom() -> Bool
}


class Hotel: BookForRoom {
    var name: String
    var location: String
    var numberOfRooms: [Room]
    var facilities: [String]
    
    init(name: String, location: String, numberOfRooms: [Room], facilities: [String]) {
        self.name = name
        self.location = location
        self.numberOfRooms = numberOfRooms
        self.facilities = facilities
    }
    
    func bookRoom() -> Bool {
        for room in numberOfRooms {
            if room.isAvailable {
                room.isAvailable = false
                return true
            }
        }
        return false
    }
}

class Room {
    var roomNumber: Int
    var isAvailable: Bool
    
    init(roomNumber: Int, isAvailable: Bool = true) {
        self.roomNumber = roomNumber
        self.isAvailable = isAvailable
    }
}

class Reservation {
    var hotel: Hotel
    var user: User
    var room: Room
    var status: String
    
    init(hotel: Hotel, user: User, room: Room) {
        self.hotel = hotel
        self.user = user
        self.room = room
        self.status = "Booked"
    }
    
    func cancel() {
        status = "Cancelled"
        room.isAvailable = true
    }
    
}

class Feedback {
    var hotel: Hotel
    var user: User
    var rating: Int
    var comments: String
    
    init(hotel: Hotel, user: User, rating: Int, comments: String) {
        self.hotel = hotel
        self.user = user
        self.rating = rating
        self.comments = comments
    }
}


class NormalUser: User {
    var username: String
    var email: String
    
    init(username: String, email: String) {
        self.username = username
        self.email = email
    }
    
    func register() {
        print("\(username) has registered.")
    }
    
    func modifyDetails(newEmail: String) {
        self.email = newEmail
    }
    
    func searchHotel(byCriteria: String) -> [Hotel] {
        return [Hotel(name: "Hotel A", location: "City A", numberOfRooms: [], facilities: []),
                Hotel(name: "Hotel B", location: "City B", numberOfRooms: [], facilities: [])]
    }
}

class HotelAgent: NormalUser, HotelAgentProtocol {
    func addHotel(hotel: Hotel) {
        print("Hotel \(hotel.name) added by \(username).")
    }
    
    func updateHotelDetails(hotel: Hotel) {
        print("Hotel \(hotel.name) details updated by \(username).")
    }
}

class Administrator: NormalUser, AdministratorProtocol {
    func approveHotel(hotel: Hotel) {
        print("Hotel \(hotel.name) approved by \(username).")
    }
    
    func deleteUser(user: User) {
        print("\(user.username) deleted by admin \(username).")
    }
    
    func deleteHotel(hotel: Hotel) {
        print("Hotel \(hotel.name) deleted by admin \(username).")
    }
}


let room1 = Room(roomNumber: 101)
let room2 = Room(roomNumber: 102)
let hotel = Hotel(name: "Taj Hotel", location: "Mumbai", numberOfRooms: [room1, room2], facilities: ["Free WiFi", "Swiming Pool","Night Club"])

let normalUser = NormalUser(username: "varun_singh", email: "varun3455@gmail.com")
let hotelAgent = HotelAgent(username: "agent_1", email: "agent1@gmail.com")
let admin = Administrator(username: "admin", email: "admin@gmail.com")

normalUser.register()
let hotelsFound = normalUser.searchHotel(byCriteria: "City A")
print("Found hotels: \(hotelsFound.map { $0.name })")

hotelAgent.addHotel(hotel: hotel)

admin.approveHotel(hotel: hotel)

if hotel.bookRoom() {
    print("Room booked successfully.")
} else {
    print("No rooms available.")
}

admin.deleteHotel(hotel: hotel)
