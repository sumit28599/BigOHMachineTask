//A parking lot or car park is a dedicated cleared area that is intended for parking vehicles.
//Use case
//Here are the main Actors in our system:
//Admin: Mainly responsible for adding and modifying parking floors, parking spots, entrance, and exit panels, adding/removing parking attendants, etc.
//Customer: All customers can get a parking ticket and pay for it.
//Parking attendant: Parking attendants can do all the activities on the customer’s behalf, and can take cash for ticket payment.
//System: To display messages on different info panels, as well as assigning and removing a vehicle from a parking spot.
//Here are the top use cases for Parking Lot:
//Add/Remove/Edit parking floor: To add, remove or modify a parking floor from the system. Each floor can have its own display board to show free parking spots.
//Add/Remove/Edit parking spot: To add, remove or modify a parking spot on a parking floor.
//Add/Remove a parking attendant: To add or remove a parking attendant from the system.
//Take ticket: To provide customers with a new parking ticket when entering the parking lot.
//Scan ticket: To scan a ticket to find out the total charge.
//Credit card payment: To pay the ticket fee with credit card.
//Cash payment: To pay the parking ticket through cash.
//Add/Modify parking rate: To allow admin to add or modify the hourly parking rate
//
//System Requirements
//We will focus on the following set of requirements while designing the parking lot:
//The parking lot should have multiple floors where customers can park their cars.
//The parking lot should have multiple entry and exit points.
//Customers can collect a parking ticket from the entry points and can pay the parking fee at the exit points on their way out.
//Customers can pay the tickets at the automated exit panel or to the parking attendant.
//Customers can pay via both cash and credit cards.
//Customers should also be able to pay the parking fee at the customer’s info portal on each floor. If the customer has paid at the info portal, they don’t have to pay at the exit.
//The system should not allow more vehicles than the maximum capacity of the parking lot. If the parking is full, the system should be able to show a message at the entrance panel and on the parking display board on the ground floor.
//Each parking floor will have many parking spots. The system should support multiple types of parking spots such as Compact, Large, Handicapped, Motorcycle, etc.
//The Parking lot should have some parking spots specified for electric cars. These spots should have an electric panel through which customers can pay and charge their vehicles.
//The system should support parking for different types of vehicles like car, truck, van, motorcycle, etc.
//Each parking floor should have a display board showing any free parking spot for each spot type.
//The system should support a per-hour parking fee model. For example, customers have to pay $4 for the first hour, $3.5 for the second and third hours, and $2.5 for all the remaining hours.



import Foundation

class ParkingTicket {
    let ticketNumber: String
    let ticketIssueTime: Date
    var paymentStatus: Bool
    
    init(ticketNumber: String, ticketIssueTime: Date) {
        self.ticketNumber = ticketNumber
        self.ticketIssueTime = ticketIssueTime
        self.paymentStatus = false
    }
    
    func totalParkingFess(forHours hours: Int) -> Double {
        var parkingfees = 0.0
        if hours > 0 {
            parkingfees += Double(min(hours, 1)) * 4.0
        }
        if hours > 1 {
            parkingfees += Double(min(hours - 1, 2)) * 3.5
        }
        if hours > 3 {
            parkingfees += Double(hours - 3) * 2.5
        }
        return parkingfees
    }
}


protocol PaymentMethod {
    func pay(amount: Double) -> Bool
}

class CreditCardPayment: PaymentMethod {
    func pay(amount: Double) -> Bool {
        print("Paid $ \(amount) via Credit Card")
        return true
    }
}

class CashPayment: PaymentMethod {
    func pay(amount: Double) -> Bool {
        print("Paid $\(amount) in Cash")
        return true
    }
}


class ParkingSpot {
    let id: String
    let vehicletype: String
    var isOccupied: Bool
    
    init(id: String, vehicletype: String) {
        self.id = id
        self.vehicletype = vehicletype
        self.isOccupied = false
    }
    
    func occupySpot() {
        self.isOccupied = true
    }
    
    func vacateSpot() {
        self.isOccupied = false
    }
}


class ParkingFloor {
    let floorNumber: Int
    var parkingSpots: [ParkingSpot]
    
    init(floorNumber: Int) {
        self.floorNumber = floorNumber
        self.parkingSpots = []
    }
    
    func addParkingSpot(spot: ParkingSpot) {
        self.parkingSpots.append(spot)
    }
    
    func availableSpots() -> [ParkingSpot] {
        return self.parkingSpots.filter { !$0.isOccupied }
    }
    
    func displayAvailableSpots() {
        let available = availableSpots()
        print("Floor \(floorNumber) Available spots: \(available.count)")
    }
}


class ParkingAttendant {
    let attendentName: String
    
    init(attendentName: String) {
        self.attendentName = attendentName
    }
    
    func issueTicket(forSpot spot: ParkingSpot) -> ParkingTicket {
        let ticket = ParkingTicket(ticketNumber: UUID().uuidString, ticketIssueTime: Date())
        spot.occupySpot()
        print("\(attendentName) issued ticket \(ticket.ticketNumber) for spot \(spot.id)")
        return ticket
    }
    
    func requestForPayment(ticket: ParkingTicket, amount: Double, paymentMethod: PaymentMethod) -> Bool {
        return paymentMethod.pay(amount: amount)
    }
    
    func scanTicket(ticket: ParkingTicket) -> Double {
        let elapsedTime = Int(Date().timeIntervalSince(ticket.ticketIssueTime) / 3600)
        return ticket.totalParkingFess(forHours: elapsedTime)
    }
}


class InfoPanel {
    func displayMessage(message: String) {
        print("Info Panel: \(message)")
    }
}


class Admin {
    var parkingFloors: [ParkingFloor]
    
    init() {
        self.parkingFloors = []
    }
    
    func addParkingFloor(floor: ParkingFloor) {
        self.parkingFloors.append(floor)
        print("Admin added Floor \(floor.floorNumber)")
    }
    
    func removeParkingFloor(floor: ParkingFloor) {
        if let index = parkingFloors.firstIndex(where: { $0.floorNumber == floor.floorNumber }) {
            parkingFloors.remove(at: index)
            print("Admin removed Floor \(floor.floorNumber)")
        }
    }
    
    func addParkingSpot(toFloor floor: ParkingFloor, spot: ParkingSpot) {
        floor.addParkingSpot(spot: spot)
        print("Admin added Spot \(spot.id) to Floor \(floor.floorNumber)")
    }
    
    func removeParkingSpot(fromFloor floor: ParkingFloor, spot: ParkingSpot) {
        if let index = floor.parkingSpots.firstIndex(where: { $0.id == spot.id }) {
            floor.parkingSpots.remove(at: index)
            print("Admin removed Spot \(spot.id) from Floor \(floor.floorNumber)")
        }
    }
}


class ParkingLot {
    var floors: [ParkingFloor]
    var attendants: [ParkingAttendant]
    
    init() {
        self.floors = []
        self.attendants = []
    }
    
    func addFloor(floor: ParkingFloor) {
        floors.append(floor)
    }
    
    func addAttendant(attendant: ParkingAttendant) {
        attendants.append(attendant)
    }
    
    func isFull() -> Bool {
        return floors.allSatisfy { $0.availableSpots().isEmpty }
    }
    
    func displayFullMessage(panel: InfoPanel) {
        panel.displayMessage(message: "Parking lot is full")
    }
}


let groundFloor = ParkingFloor(floorNumber: 1)
let firstFloor = ParkingFloor(floorNumber: 2)
let spot1 = ParkingSpot(id: "A1", vehicletype: "Car")
let spot2 = ParkingSpot(id: "A2", vehicletype: "Bus")
let spot3 = ParkingSpot(id: "A3", vehicletype: "truck")

groundFloor.addParkingSpot(spot: spot1)
groundFloor.addParkingSpot(spot: spot2)
firstFloor.addParkingSpot(spot: spot3)

let admin = Admin()
admin.addParkingFloor(floor: groundFloor)
admin.addParkingFloor(floor: firstFloor)
let attendant = ParkingAttendant(attendentName: "Donald Trump")
let ticket = attendant.issueTicket(forSpot: spot1)
let payment = CreditCardPayment()
let parkingfees = attendant.scanTicket(ticket: ticket)
attendant.requestForPayment(ticket: ticket, amount: parkingfees, paymentMethod: payment)
groundFloor.displayAvailableSpots()
