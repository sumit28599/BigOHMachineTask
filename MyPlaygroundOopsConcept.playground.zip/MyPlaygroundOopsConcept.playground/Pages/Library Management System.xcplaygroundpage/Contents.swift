//A Library Management System is a software built to handle the primary housekeeping functions of a library. Libraries rely on library management systems to manage asset collections as well as relationships with their members. Library management systems help libraries keep track of the books and their checkouts, as well as members’ subscriptions and profiles.
//Library management systems also involve maintaining the database for entering new books and recording books that have been borrowed with their respective due dates.
//System Requirements
//Always clarify requirements at the beginning of the interview. Be sure to ask questions to find the exact scope of the system that the interviewer has in mind.
//We will focus on the following set of requirements while designing the Library Management System:
//Any library member should be able to search books by their title, author, subject category as well by the publication date.
//Each book will have a unique identification number and other details including a rack number which will help to physically locate the book.
//There could be more than one copy of a book, and library members should be able to check-out and reserve any copy. We will call each copy of a book, a book item.
//The system should be able to retrieve information like who took a particular book or what are the books checked-out by a specific library member.
//There should be a maximum limit (5) on how many books a member can check-out.
//There should be a maximum limit (10) on how many days a member can keep a book.
//The system should be able to collect fines for books returned after the due date.
//Members should be able to reserve books that are not currently available.
//The system should be able to send notifications whenever the reserved books become available, as well as when the book is not returned within the due date.
//Each book and member card will have a unique barcode. The system will be able to read barcodes from books and members’ library cards.
//Use case diagram
//We have three main actors in our system:
//Librarian: Mainly responsible for adding and modifying books, book items, and users. The Librarian can also issue, reserve, and return book items.
//Member: All members can search the catalog, as well as check-out, reserve, renew, and return a book.
//System: Mainly responsible for sending notifications for overdue books, canceled reservations, etc.
//Here are the top use cases of the Library Management System:
//Add/Remove/Edit book: To add, remove or modify a book or book item.
//Search catalog: To search books by title, author, subject or publication date.
//Register new account/cancel membership: To add a new member or cancel the membership of an existing member.
//Check-out book: To borrow a book from the library.
//Reserve book: To reserve a book which is not currently available.
//Renew a book: To reborrow an already checked-out book.
//Return a book: To return a book to the library which was issued to a member.


import Foundation

enum SpecificRole {
    case admin, librarian, user
}

class Book {
    var bookId: String
    var title: String
    var author: String
    var subject: String
    var publicationDate: Date
    var rackNumber: String
    var dueDate: Date?
    
    init(bookId: String, title: String, author: String, subject: String, publicationDate: Date, rackNumber: String, dueDate: Date? = nil) {
        self.bookId = bookId
        self.title = title
        self.author = author
        self.subject = subject
        self.publicationDate = publicationDate
        self.rackNumber = rackNumber
        self.dueDate = dueDate
    }
}



class BookManager {
    var numberOfBooks: [String: [Book]] = [:]
    
    func addBook(book: Book, subject: String, addBy:User) {
        guard addBy.specificRole == .librarian else {
            print("Access Denied: Only librarian can add a book")
            return
        }
        
        if numberOfBooks[subject]?.count ?? 0 < 5 {
            numberOfBooks[subject, default: []].append(book)
            print("New Book Added: \(book.title) (bookId: \(book.bookId)) to subject \(subject)")
        } else {
            print("Cannot add more than 5 books to subject \(subject)")
        }
    }
    
    func removeBook(bookId: String,subject: String, removeBy:User) {
        guard removeBy.specificRole == .librarian else {
            print("Access Denied: Only librarian can remove a book")
            return
        }
        
        if var books = numberOfBooks[subject] {
            if let index = books.firstIndex(where: { $0.bookId == bookId }) {
                print("The book \(books[index].title) (bookId: \(bookId)) has been removed from subject \(subject)")
                books.remove(at: index)
                numberOfBooks[subject] = books
            }
        }
        
    }
    
    func assignBook(bookId: String, assignnedPerson: User,subject: String, assignBy:User) {
        guard assignBy.specificRole == .librarian else {
            print("Access Denied: Only librarian can assign a book")
            return
        }
        
        if let book = numberOfBooks[subject]?.first(where: { $0.bookId == bookId }) {
            print("The book \(book.title) (bookId: \(book.bookId)) has been assigned to \(assignnedPerson.username) and  \(assignnedPerson.userId) in subject is \(subject)")
        } else {
            print("No book found with bookId: \(bookId) in subject is \(subject)")
        }
    }
    
    func updateBook(bookId: String, updateBook:Book,subject: String, updateBy:User) {
        guard updateBy.specificRole == .librarian else {
            print("Access Denied: Only librarian can update a book")
            return
        }
        
        if var books = numberOfBooks[subject] {
            if let index = books.firstIndex(where: { $0.bookId == bookId }) {
                var book = books[index]
//                if let newTitle = newTitle {
//                    book.title = newTitle
//                }
//                if let newAuthor = newAuthor {
//                    book.author = newAuthor
//                }
                books[index] = book
                numberOfBooks[subject] = books
                print("The book \(book.bookId) in subject \(subject) has been updated. New title: \(book.title), New author: \(book.author)")
            } else {
                print("No book found with bookId: \(bookId) in subject is \(subject)")
            }
        }
    }
    
    func searchBookById(bookId: String, subject: String) -> Book? {
        if let book = numberOfBooks[subject]?.first(where: { $0.bookId == bookId }) {
            print("Book found: \(book.title) (Book ID: \(book.bookId)) in subject is \(subject)")
            return book
        } else {
            print("No book found with bookId: \(bookId) in subject is \(subject)")
            return nil
        }
    }
}

class User {
    var userId: String
    var username: String
    var specificRole: SpecificRole
    
    init(userId: String, username: String,specificRole: SpecificRole) {
        self.userId = userId
        self.username = username
        self.specificRole = specificRole
    }
    
}

class UserManager {
    var users:[User] = []
    
    func registerUser(user:User, registerBy:User) -> [User] {
        guard registerBy.specificRole == .librarian || registerBy.specificRole == .admin else {
            print("Access Denied: Only librarian or admin can add User")
            return []
        }
        users.append(user)
        print("\(user.username) have registered:  userid is \(user.userId)")
        return users
    }
    
    
    func removeUser(userId: String, registerBy:User) -> [User]{
        guard registerBy.specificRole == .librarian || registerBy.specificRole == .admin else {
            print("Access Denied: Only librarian or admin can remove User")
            return []
        }
        if let index = users.firstIndex(where: { $0.userId == userId }) {
            print("This \(users[index].username) have removed from system")
            users.remove(at: index)
        }
        return users
    }
}

class LibraryManagementSystem:@unchecked Sendable {
    static let shared = LibraryManagementSystem(usermanager: UserManager(), bookmanager: BookManager())

    let usermanager: UserManager
    let bookmanager: BookManager
    
    private init(usermanager: UserManager, bookmanager: BookManager) {
        self.usermanager = usermanager
        self.bookmanager = bookmanager
    }
}


let book1 = Book(bookId: "S023", title: "Swift", author: "Apple", subject: "Programming", publicationDate: Date(), rackNumber: "L01")
let book2 = Book(bookId: "S024", title: "Java", author: "Jack", subject: "Programming", publicationDate: Date(), rackNumber: "L01")
let book3 = Book(bookId: "S025", title: "Physics", author: "Raman", subject: "Science", publicationDate: Date(), rackNumber: "L02")
let book4 = Book(bookId: "S026", title: "Mathematics", author: "Aryabhat", subject: "Math", publicationDate: Date(), rackNumber: "L02")
let book5 = Book(bookId: "S027", title: "True Story", author: "Kabir", subject: "Story", publicationDate: Date(), rackNumber: "L03")
let book6 = Book(bookId: "S028", title: "Snow white", author: "Raheem", subject: "Story", publicationDate: Date(), rackNumber: "L03")

let admin = User(userId: "U001", username: "Deepak Kumar", specificRole: .admin)
let user1 = User(userId: "U002", username: "vinay Kumar", specificRole: .admin)
let assignnedPerson = User(userId: "U003", username: "Ajay Kumar", specificRole: .user)
let librarian = User(userId: "L004", username: "Ajeet Kumar", specificRole: .librarian)
let bookmanager = BookManager()
let usermanager = UserManager()

LibraryManagementSystem.shared.usermanager.registerUser(user: user1, registerBy: librarian)
LibraryManagementSystem.shared.usermanager.removeUser(userId: user1.userId, registerBy: librarian)
LibraryManagementSystem.shared.usermanager.registerUser(user: librarian, registerBy: admin)
LibraryManagementSystem.shared.usermanager.removeUser(userId: librarian.userId, registerBy: admin)
LibraryManagementSystem.shared.bookmanager.addBook(book: book1, subject: book1.subject, addBy: librarian)
LibraryManagementSystem.shared.bookmanager.assignBook(bookId: book1.bookId, assignnedPerson: assignnedPerson, subject: book1.subject, assignBy: librarian)
LibraryManagementSystem.shared.bookmanager.updateBook(bookId: book1.bookId, updateBook: book6, subject: book1.subject, updateBy: librarian)
LibraryManagementSystem.shared.bookmanager.searchBookById(bookId: book6.bookId, subject: book6.subject)




































//class LibraryManagementSystem {
//    var numberofbbooks:[Book] = []
//    var students: [Student] = []
//    var librarians: [Librarian] = []
//
//    func addBooksByLMS(book:Book,specificRole: SpecificRole) -> [Student] {
//        guard specificRole == .libraryMSystem else {
//            print("Access Denied: Only LMS add Book")
//            return []
//        }
//        numberofbbooks.append(book)
//        print("New Book Add: \(book.title) bookId is \(book.bookId)")
//        return students
//    }
//    func registerStudent(student:Student,specificRole: SpecificRole) -> [Student] {
//        guard specificRole == .libraryMSystem else {
//            print("Access Denied: Only LMS add student")
//            return []
//        }
//        students.append(student)
//        print("New Student registered: \(student.studentname) memberid is \(student.studentId)")
//        return students
//    }
//
//
//    func removeStudent(studentId: String,specificRole: SpecificRole) -> [Student]{
//        guard specificRole == .libraryMSystem else {
//            print("Access Denied: Only LMS remove student")
//            return []
//        }
//        if let index = students.firstIndex(where: { $0.studentId == studentId }) {
//            print("This Student \(students[index].studentname) have removed from system")
//            students.remove(at: index)
//        }
//        return students
//    }
//
//    func registerLibrarian(librarianId:Librarian,specificRole: SpecificRole) -> [Librarian] {
//        guard specificRole == .libraryMSystem else {
//            print("Access Denied: Only LMS add Librarian")
//            return []
//        }
//        librarians.append(librarianId)
//        print("New Student registered: \(librarianId.librarianName) memberid is \(librarianId.librarianId)")
//        return librarians
//    }
//
//
//    func removeLibrarian(librarianId: String,specificRole: SpecificRole) -> [Librarian]{
//        guard specificRole == .libraryMSystem else {
//            print("Access Denied: Only LMS remove Librarian")
//            return []
//        }
//        if let index = librarians.firstIndex(where: { $0.librarianId == librarianId }) {
//            print("This Student \(students[index].studentname) have removed from system")
//            librarians.remove(at: index)
//        }
//        return librarians
//    }
//
//
//}


//class Student {
//    var studentId: String
//    var studentname: String
//    var numberOfBooks: [Book] = []
//
//    init(studentId: String, studentname: String) {
//        self.studentId = studentId
//        self.studentname = studentname
//    }
//
//    func getBookByStudent(book:Book,specificRole: SpecificRole) {
//        guard specificRole == .libraryMSystem else {
//            print("Access Denied: Student Only wiil take book from LSM")
//            return
//        }
//        numberOfBooks.append(book)
//        print("Number of book here \(numberOfBooks.count)")
//    }
//
//    func returnBookByStudent (book:Book,specificRole: SpecificRole) {
//        guard specificRole == .libraryMSystem else {
//            print("Access Denied: Only Student can return book from LSM.")
//            return
//        }
//        if let index = numberOfBooks.firstIndex(where: { $0 === book }) {
//            numberOfBooks.remove(at: index)
//            print("Number of book here \(numberOfBooks.count)")
//        }
//    }
//
//    func searchBookByStudent(title: String? = nil, author: String? = nil, subject: String? = nil, publicationDate: Date? = nil) -> [Book] {
//        return numberOfBooks.filter { book in
//            (title == nil || book.title.contains(title!)) &&
//            (author == nil || book.author.contains(author!)) &&
//            (subject == nil || book.subject.contains(subject!)) &&
//            (publicationDate == nil || Calendar.current.isDate(book.publicationDate, inSameDayAs: publicationDate!))
//        }
//    }
//}


//class Librarian {
//    var librarianId: String
//    var librarianName: String
//    var numberOfBooksInLibrary: [Book] = []
//
//    init(librarianId: String, librarianName: String) {
//        self.librarianId = librarianId
//        self.librarianName = librarianName
//    }
//
//    func addBookByLibrarian(book:Book,specificRole: SpecificRole) {
//        guard specificRole == .librarian else {
//            print("Access Denied: Only Librarian will add book.")
//            return
//        }
//        numberOfBooksInLibrary.append(book)
//        print("Number of book here \(numberOfBooksInLibrary.count)")
//    }
//
//
//    func returnBookByLirarian (book:Book,specificRole: SpecificRole) {
//        guard specificRole == .librarian else {
//            print("Access Denied: Only Librarian can return books.")
//            return
//        }
//        if let index = numberOfBooksInLibrary.firstIndex(where: { $0 === book }) {
//            numberOfBooksInLibrary.remove(at: index)
//            print("Number of book here \(numberOfBooksInLibrary.count)")
//        }
//    }
//
//    func searchBookByLibrarian(title: String? = nil, author: String? = nil, subject: String? = nil, publicationDate: Date? = nil) -> [Book] {
//        return numberOfBooksInLibrary.filter { book in
//            (title == nil || book.title.contains(title!)) &&
//            (author == nil || book.author.contains(author!)) &&
//            (subject == nil || book.subject.contains(subject!)) &&
//            (publicationDate == nil || Calendar.current.isDate(book.publicationDate, inSameDayAs: publicationDate!))
//        }
//    }
//
//    func removeBookByLibrarian (book:Book,specificRole: SpecificRole) {
//        guard specificRole == .librarian else {
//            print("Access Denied: Only Librarian will remove book.")
//            return
//        }
//        if let index = numberOfBooksInLibrary.firstIndex(where: { $0 === book }) {
//            numberOfBooksInLibrary.remove(at: index)
//            print("Number of book here \(numberOfBooksInLibrary.count)")
//        }
//    }
//}





//let book1 = Book(bookId: "123", title: "Swift Programming", author: "Apple", subject: "Programming", publicationDate: Date(), rackNumber: "L01")
//book1.display()
//
//let students = Student(studentId: "S01", studentname: "Deepak")
//students.getBookByStudent(book: book1, specificRole: .student)
//
//let librarian = Librarian(librarianId: "234", librarianName: "Ajay singh")
//librarian.addBookByLibrarian(book: book1, specificRole: .librarian)
//
//let libraryMS = LibraryManagementSystem()
//libraryMS.addBooksByLMS(book: book1, specificRole: .libraryMSystem)
//libraryMS.registerLibrarian(librarianId: librarian, specificRole: .libraryMSystem)
//
//
//


//
//enum SpecificRole {
//    case librarian, member
//}
//
//class Book {
//    var bookId: String
//    var title: String
//    var author: String
//    var subject: String
//    var publicationDate: Date
//
//    init(bookId: String, title: String, author: String, subject: String, publicationDate: Date) {
//        self.bookId = bookId
//        self.title = title
//        self.author = author
//        self.subject = subject
//        self.publicationDate = publicationDate
//    }
//}
//
//class BookItem {
//    var book: Book
//    var rackNumber: String
//    var isCheckedOut: Bool = false
//    var dueDate: Date?
//
//    init(book: Book, rackNumber: String) {
//        self.book = book
//        self.rackNumber = rackNumber
//    }
//
//    func checkOut(forDays days: Int) -> Bool {
//        if isCheckedOut {
//            print("Book have already checkout")
//            return false
//        }
//        isCheckedOut = true
//        self.dueDate = Calendar.current.date(byAdding: .day, value: days, to: Date())
//        return true
//    }
//
//    func returnBook() {
//       isCheckedOut = false
//        print("Book have returned")
//        self.dueDate = nil
//    }
//}
//
//class User {
//    var userId: String
//    var username: String
//    var numberOfBooks: [BookItem] = []
//    let specificRole: SpecificRole
//
//    init(userId: String, username: String, specificRole: SpecificRole) {
//        self.userId = userId
//        self.username = username
//        self.specificRole = specificRole
//    }
//
//    func borrowBookByUser(bookItem: BookItem) {
//        guard specificRole == .member else {
//            print("Only members can borrow books.")
//            return
//        }
//        numberOfBooks.append(bookItem)
//        print("Number of book here \(numberOfBooks.count)")
//    }
//
//    func returnBookByUser(bookItem: BookItem) {
//        guard specificRole == .member else {
//            print("Only members can return books.")
//            return
//        }
//        if let index = numberOfBooks.firstIndex(where: { $0 === bookItem }) {
//            numberOfBooks.remove(at: index)
//            print("Number of book here \(numberOfBooks.count)")
//        }
//    }
//}
//
//class Librarian: User {
//    var checkedOutBooks: [BookItem] = []
//    var reservedBooks: [BookItem] = []
//    let library:Library
//
//    let maxBooksAllowed = 5
//    let maxDaysAllowed = 10
//
//    init(librarianId: String, name: String,library:Library) {
//        self.library = library
//        super.init(userId: librarianId, username: name, specificRole: .librarian)
//    }
//
//    func checkOutBookByLibrarian(bookItem: BookItem) -> Bool {
//        guard specificRole == .librarian else {return false}
//        if checkedOutBooks.count >= maxBooksAllowed {
//            print("You cannot check out more than \(maxBooksAllowed) books.")
//            return false
//        }
//
//        if bookItem.checkOut(forDays: maxDaysAllowed) {
//            checkedOutBooks.append(bookItem)
//            print("Librarian have checkedOutBooks .\(checkedOutBooks.count)")
//            return true
//        }
//        return false
//    }
//
//    func returnBookByLibrarian(bookItem: BookItem) {
//        guard specificRole == .librarian else {
//            print("Only librarian can return books.")
//            return
//        }
//        if let index = checkedOutBooks.firstIndex(where: { $0 === bookItem }) {
//            checkedOutBooks.remove(at: index)
//            bookItem.returnBook()
//            print("Books have return form rack Number \(bookItem.rackNumber)")
//        }
//    }
//
//    func reserveBookByLibrarian(bookItem: BookItem) {
//        guard specificRole == .librarian else {
//            print("Only librarian can reserve books.")
//            return
//        }
//        reservedBooks.append(bookItem)
//    }
//
//    func removeBookByLibrarian(book: Book, rackNumber: String) {
//        guard specificRole == .librarian else {
//            print("Only librarian can remove books.")
//            return
//        }
//        library.removeBook(book: book, rackNumber: rackNumber)
//
//    }
//
//
//    func getMemberByLibrarian(memberId: String) {
//        guard specificRole == .librarian else {
//            print("Only librarian can get member.")
//            return
//        }
//        library.getMember(memberId: memberId)
//    }
//
//    func removeMemberByLibrarian(memberId: String) {
//        guard specificRole == .librarian else {
//            print("Only librarian can remove member.")
//            return
//        }
//        library.removeMember(memberId: memberId)
//    }
//}
//
//
//
//class Library {
//    var books: [BookItem] = []
//    var members: [User] = []
//
//    func addBook(book: Book, rackNumber: String,specificRole: SpecificRole) {
//        guard specificRole == .librarian else {
//            print("Book will add only by librarian")
//            return
//        }
//        let bookItem = BookItem(book: book, rackNumber: rackNumber)
//        books.append(bookItem)
//        print("Book '\(book.title)' added to the library.")
//    }
//
//    func removeBook(book: Book, rackNumber: String) {
//        if let index = books.firstIndex(where: { $0 === book }) {
//            books.remove(at: index)
//            print("Book '\(book.title)' remove from the library.")
//        }
//    }
//
//
//
//    func searchBooks(title: String? = nil, author: String? = nil, subject: String? = nil, publicationDate: Date? = nil) -> [BookItem] {
//        return books.filter { bookItem in
//            (title == nil || bookItem.book.title.contains(title!)) &&
//            (author == nil || bookItem.book.author.contains(author!)) &&
//            (subject == nil || bookItem.book.subject.contains(subject!)) &&
//            (publicationDate == nil || Calendar.current.isDate(bookItem.book.publicationDate, inSameDayAs: publicationDate!))
//        }
//    }
//    func registerMember(user:User) -> User {
//        members.append(user)
//        print("New member registered: \(user.username) memberid is \(user.userId)")
//        return user
//    }
//
//    func getMember(memberId: String){
//        members.first { $0.userId == memberId }
//        print("Get Member Name is'\(members[0].username)'")
//    }
//
//    func removeMember(memberId: String) {
//        if let index = members.firstIndex(where: { $0.userId == memberId }) {
//            print("Member have removed from the library: \(members[index].username)")
//            members.remove(at: index)
//
//        }
//    }
//
//}
//
//
//let book1 = Book(bookId: "B001", title: "The Swift Programming Language", author: "Apple Inc.", subject: "Programming", publicationDate: Date())
//let book2 = Book(bookId: "B002", title: "Java Programming Language", author: "Deepak Kumar", subject: "Programming", publicationDate: Date())
//let book3 = Book(bookId: "B003", title: "Python Programming Language", author: "Arun Kumar", subject: "Programming", publicationDate: Date())
//
//let library = Library()
//
//library.addBook(book: book1, rackNumber: "R001", specificRole: .librarian)
//library.addBook(book: book2, rackNumber: "R002", specificRole: .librarian)
//library.addBook(book: book3, rackNumber: "R003", specificRole: .librarian)
//
//let bookItem = BookItem(book: book1, rackNumber: "R001")
//let bookItem1 = BookItem(book: book2, rackNumber: "R001")
//let bookItem2 = BookItem(book: book3, rackNumber: "R001")
//let bookItem3 = BookItem(book: book1, rackNumber: "R001")
//let bookItem4 = BookItem(book: book2, rackNumber: "R001")
//let bookItem5 = BookItem(book: book3, rackNumber: "R001")
//
//let user = User(userId: "US01", username: "Varun", specificRole: .member)
//
//
//let librarian = Librarian(librarianId: "L001", name: "Varun", library: library)
//let member = library.registerMember(user: user)
//library.getMember(memberId: "US01")
//library.removeMember(memberId: "US01")
//member.borrowBookByUser(bookItem: bookItem2)
//librarian.checkOutBookByLibrarian(bookItem: bookItem)
//librarian.checkOutBookByLibrarian(bookItem: bookItem1)
//librarian.checkOutBookByLibrarian(bookItem: bookItem2)
//librarian.checkOutBookByLibrarian(bookItem: bookItem3)
//librarian.checkOutBookByLibrarian(bookItem: bookItem4)
//librarian.checkOutBookByLibrarian(bookItem: bookItem5)
//librarian.checkOutBookByLibrarian(bookItem: bookItem2)
//
//librarian.returnBookByLibrarian(bookItem: bookItem5)
//librarian.returnBookByLibrarian(bookItem: bookItem3)




//class BookManager {
//    var numberOfBooks:[Book] = []
//
//
//    func addBook(book:Book,specificRole: SpecificRole) -> [Book]{
//        guard specificRole == .librarian else {
//            print("Access Denied: Only librarian add Book")
//            return []
//        }
//
//        if numberOfBooks.count < 5 {
//            numberOfBooks.append(book)
//            print("New Book Add: \(book.title) bookId is \(book.bookId) \(numberOfBooks.count)")
//        } else {
//            print("We can not add more than 5 books")
//        }
//
//        return numberOfBooks
//    }
//
//    func removeBook(bookId: String,specificRole: SpecificRole) -> [Book]{
//        guard specificRole == .librarian else {
//            print("Access Denied: Only librarian remove student")
//            return []
//        }
//        if let index = numberOfBooks.firstIndex(where: { $0.bookId == bookId }) {
//            print("This Book \(numberOfBooks[index].title) have removed from system")
//            numberOfBooks.remove(at: index)
//        }
//        return numberOfBooks
//    }
//
//    func assignBook(bookId: String, toUser user: String, specificRole: SpecificRole) {
//        guard specificRole == .librarian else {
//            print("Access Denied: Only librarian can assign a book")
//            return
//        }
//
//        if let book = numberOfBooks.first(where: { $0.bookId == bookId }) {
//            print("The book \(book.title) (bookId: \(book.bookId)) has been assigned to \(user)")
//        } else {
//            print("No book found with bookId: \(bookId) \(numberOfBooks.first(where: { $0.bookId == bookId }))")
//        }
//    }
//
//    func updateBook(bookId: String, newTitle: String?, newAuthor: String?, specificRole: SpecificRole) -> [Book] {
//        guard specificRole == .librarian else {
//            print("Access Denied: Only librarian can update a book")
//            return []
//        }
//
//        if let index = numberOfBooks.firstIndex(where: { $0.bookId == bookId }) {
//            var book = numberOfBooks[index]
//            if let newTitle = newTitle {
//                book.title = newTitle
//            }
//            if let newAuthor = newAuthor {
//                book.author = newAuthor
//            }
//            numberOfBooks[index] = book
//            print("The book \(book.bookId) has been updated. New title: \(book.title), New author: \(book.author)")
//        } else {
//            print("No book found with bookId: \(bookId)")
//        }
//
//        return numberOfBooks
//    }
//
//    func searchBookById(bookId: String) -> Book? {
//        if let book = numberOfBooks.first(where: { $0.bookId == bookId }) {
//            print("Book found: \(book.title) (Book ID: \(book.bookId))")
//            return book
//        } else {
//            print("No book found with bookId: \(bookId)")
//            return nil
//        }
//    }
//}
